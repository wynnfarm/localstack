function handler() {
    console.log('my function')
}